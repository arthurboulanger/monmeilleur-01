Paulund Syntax Highlighter
===================================

A WordPress plugin that will create shortcodes to add code snippets to your WordPress site using prism.js to style the code.